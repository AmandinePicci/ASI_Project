package com.project.model.dto;

public enum FireType {
	A,B_Gasoline,B_Alcohol,B_Plastics,C_Flammable_Gases,D_Metals,E_Electric;
}
