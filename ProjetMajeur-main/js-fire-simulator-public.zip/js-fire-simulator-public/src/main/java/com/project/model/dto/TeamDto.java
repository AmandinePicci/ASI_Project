package com.project.model.dto;

public class TeamDto {
	//TODO ???
}
